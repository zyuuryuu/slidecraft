# Step 11: JSON診断レイヤー

## 概要

LLM生成JSONの構造チェック機能 `diagnose_json()` を実装。必須フィールド検証・未知フィールド検出・類似フィールド名サジェストを提供し、LLMへのフィードバックループを支援する。

## 1. 設計方針

### 目的
- LLMが生成したJSONがDiagramSpecスキーマに適合するか**構造的に**診断
- 自動修正（auto-fix）は行わない — 問題を検出・報告し、LLMまたはユーザに修正を委ねる
- `parse_diagram_json()` の**前段**に位置し、セマンティック検証（参照整合性等）とは独立

### 診断項目

| カテゴリ | レベル | 例 |
|---------|--------|-----|
| 必須フィールド欠損 | error | `type` 未指定、`nodes[].label` 未指定 |
| 無効なenum値 | error | `type: "timeline"`, `shape: "star"` |
| 未知フィールド | warning | `shpe` (→ shape?), `layot` (→ layout?) |
| スタイル内未知フィールド | warning | `fil` (→ fill?), `border_widht` (→ border_width?) |
| JSONパースエラー | error | 不正なJSON構文 |

### 出力形式: 構造化エラーリスト

```python
@dataclass
class DiagnosticIssue:
    level: str          # "error" | "warning"
    path: str           # e.g. "nodes[2].shpe"
    message: str        # 人間向け説明
    suggestion: str     # 類似フィールド名（あれば）
```

## 2. 類似フィールド名マッチング

`difflib.SequenceMatcher` を使用。閾値 0.6 以上で最も類似度が高いフィールド名をサジェスト。

| 入力 | サジェスト | 類似度 |
|------|----------|--------|
| `shpe` | `shape` | ~0.89 |
| `form` | `from` | ~0.86 |
| `layot` | `layout` | ~0.91 |
| `fil` | `fill` | ~0.86 |
| `colour` | (なし) | <0.6 |

## 3. CLI統合

### --validate-only モード
1. **Phase 1**: `diagnose_json()` で構造診断
   - warnings → 表示（処理続行）
   - errors → 表示して終了
2. **Phase 2**: `parse_diagram_json()` でセマンティック検証
   - エッジ参照、グループ参照、レーン参照等

### API Mode 2 (--api-convert)
- LLMレスポンスに対して `diagnose_json()` を実行
- errors → 詳細表示して終了（将来: LLMに再試行指示）
- warnings → 表示して処理続行

## 4. チェック対象フィールド定義

| レベル | 既知フィールド | 必須 |
|--------|---------------|------|
| トップレベル | type, direction, title, classDefs, nodes, edges, groups, lanes, layout | type, nodes |
| Node | id, label, sublabel, shape, class, style, group, lane, icon | id, label |
| Edge | from, to, label, style | from, to |
| Group | id, label, parent, style | id, label |
| Lane | id, label, style | id, label |
| Layout | node_width, node_height, h_gap, v_gap | (なし) |
| NodeStyle | fill, border, border_width, border_dash, font_color, font_size, font_bold | (なし) |
| EdgeStyle | color, width, arrow, dash | (なし) |
| GroupStyle | border, border_dash, fill | (なし) |
| LaneStyle | header_fill, header_font_color, band_fill, border, border_width | (なし) |

## 5. テスト結果

| テスト | 結果 |
|--------|------|
| 正常JSON（issues=0） | ✓ |
| 必須フィールド欠損（type, label, to） | ✓ error検出 |
| 未知フィールド + サジェスト（shpe→shape, form→from, layot→layout） | ✓ warning + suggestion |
| 無効enum値（timeline, UP, star） | ✓ error検出 |
| スタイル内未知フィールド（fil→fill, border_widht→border_width） | ✓ warning + suggestion |
| JSONパースエラー | ✓ error検出 |
| CLI --validate-only 正常JSON | ✓ |
| CLI --validate-only 警告付きJSON | ✓ warning表示 + 処理続行 |
| CLI --validate-only エラー付きJSON | ✓ error表示 + exit 1 |

## 変更ファイル

| ファイル | 変更内容 |
|---------|---------|
| `src/diagram_schema.py` | `diagnose_json()`, `DiagnosticIssue`, `_find_similar()`, `_check_fields()`, `_check_style_fields()` 追加、既知フィールド定義 |
| `src/diagram_cli.py` | `--validate-only` に診断Phase追加、API Mode 2に診断チェック追加 |
| `PROJECT_SPEC.md` | step_11 記録追加 |
