# Step 13: コネクタルーティング＆レイアウト品質改善

## 概要

コネクタ（エッジ）のルーティングとレイアウト品質を大幅に改善。以下の8つの改善を段階的に実装：

1. **Column packing** — 8グループ→3列へ圧縮（Interval Coloring）
2. **Variable layer gaps (Algorithm A)** — グループ境界を考慮した可変レイヤーギャップ
3. **Connectivity-based cross offset (Algorithm B)** — 接続先に向かうグループ寄せ
4. **Overlap separation (Algorithm C)** — グループbbox衝突の反復解消
5. **Cross-axis stretch** — 主軸がボトルネック時にクロス軸スペースを拡張
6. **Port assignment + Nudge** — ポートオフセットで線の重なり軽減、水平セグメント重複のナッジ分散
7. **Auto-bus detection** — 条件付き自動バスライン統合
8. **Barycenter crossing minimization** — 層内ノード順序の最適化で交差24%削減

## 1. ルーティング戦略

### 分類ロジック (`_classify_edge_route`)

| 分類 | 条件 | ルーティング |
|------|------|------------|
| back_edge | サイクル検出 | U-turn routing |
| cross_group | 異グループ + Δlayer>3 + bbox分離 | Manhattan 3-segment |
| l_route | 異レイヤー + 軸方向オフセット大 | L-shaped routing |
| direct | 上記以外 | 直線コネクタ |

### Manhattan routing

TB方向: ソース底面→clear_y（ソースグループ下端+0.15"）まで降下→水平移動→ターゲット上面へ降下
フォールバック: clear_y≧ターゲット上面の場合、側面出口コリドー方式

### Fan-in/Fan-out bus lines

2つの方式が共存：
1. **Explicit bus_group**: エッジに `bus_group` キー指定（最優先）
2. **Auto-detection**: 以下の全条件を満たす場合に自動統合
   - Fan-in（N≥2ソース→1ターゲット）or Fan-out（1ソース→N≥2ターゲット）
   - グループ内のエッジに**ラベルが1つもない**
   - 全エッジが**同一スタイル**（color, dash, width一致）
   - back-edge でない

設計原則: **デフォルト = 統合、例外 = 個別** — ラベルやスタイル差は「この接続は特別」のシグナル。

## 2. レイアウトアルゴリズム

### Column Packing (Interval Coloring)
- グループのレイヤー範囲を区間として扱い、重ならないグループを同一列に配置
- 列内の接続密度に基づき、高接続列を中央に配置

### Variable Layer Gaps (Algorithm A)
- グループ境界がレイヤー間にある場合: `end_pad + visual_gap + start_pad + label_height`
- 同一グループ内レイヤー間: `main_gap × 0.25`（コンパクト）
- Scaled group padding: `max(layout_scale, 0.4)` で鶏卵問題を解決

### Cross-axis Stretch
- 主軸がスケールボトルネックの場合、クロス軸のスペーシングを拡大（MAX_CROSS_STRETCH=2.5）
- ノードサイズは変更せず、間隔のみ拡張

### Crossing Minimization (Barycenter法)
- 各ノードの「隣接層にある接続先の平均位置」で並べ替え
- Forward sweep (Layer 0→N) + Backward sweep (Layer N→0) × 4回反復
- グループ制約維持: グループ内でのみ並べ替え、グループ間順序もメンバー平均baryで最適化
- Enterprise networkで交差 25→19（24%削減）

## 3. 2フェーズエッジ描画パイプライン

### Phase 1: パス計画
L-route と Manhattan のパスを計算して `planned_paths` に蓄積（描画しない）。
Back-edge と direct connector は即座に描画。

### Phase 2: Nudge
`_nudge_overlapping_segments()` が全計画パスの水平セグメントを分析：
1. 水平セグメント抽出
2. y座標が近い（±73000 EMU）セグメントをクラスタリング
3. 各クラスタ内のx範囲重複をスイープラインで検出
4. 重複グループ内のセグメントを中心から等間隔に分散

### Phase 3: 描画
`_draw_planned_path()` がナッジ済みパスを描画 + ラベル配置。

## 4. ポートアサインメント

`_compute_port_offsets()`:
- 同一ノードの出入エッジを、隣接ノードのcross-axis位置でソート
- ノード辺上の `[-0.35, +0.35]` 範囲に均等分配
- L-route, Manhattan, direct すべてのルーティングに適用

## 5. Enterprise Network テスト結果

49エッジの処理内訳:
- **23本**: 自動バス統合（9バスライン）
- **26本**: 個別ルーティング（ラベル付き/スタイル差あり）

ルーティング分類:
| 分類 | エッジ数 | 代表例 |
|------|---------|--------|
| auto-bus | 23 | fw_int→web1,2,3, api1→app1,2,3, app1,2,3→cache |
| cross_group | ~7 | prometheus→app1, vault→k8s_master |
| l_route | ~10 | app1→db_master, app3→k8s_master |
| direct | ~9 | core_sw1→core_sw2, prometheus→grafana |

## 6. 新規・変更関数

| 関数 | 役割 |
|------|------|
| `_classify_edge_route()` | グループ関係・レイヤー距離に基づくルーティング分類 |
| `_plan_manhattan_route()` | Manhattan路計算（描画なし、2フェーズ用） |
| `_draw_manhattan_route()` | Manhattan路描画（レガシー互換） |
| `_draw_fan_in_bus()` | Fan-in バスライン描画 |
| `_draw_fan_out_bus()` | Fan-out バスライン描画 |
| `_compute_port_offsets()` | ポートオフセット計算 |
| `_cp_coords()` | port_offset対応に拡張 |
| `_nudge_overlapping_segments()` | 水平セグメント重なり検出・ナッジ |
| `_draw_planned_path()` | 計画済みパスの描画 |
| `_order_within_layers()` | Barycenter法に全面改修 |
| `_separate_overlapping_groups()` | 両軸対応+margin_top対応に改修 |

## 7. テスト結果

| テスト | 結果 |
|--------|------|
| Enterprise network (35 nodes, 49 edges) | ✓ |
| Flowchart (back-edge付き) | ✓ |
| Fan-in bus (explicit bus_group) | ✓ |
| Fan-out bus (explicit bus_group) | ✓ |
| Auto-merge fan-out (no bus_group) | ✓ |
| No auto-merge when label present | ✓ |
| LR direction flowchart | ✓ |
| Network with dash style | ✓ |
| Crossing minimization diamond | ✓ |

## 変更ファイル

| ファイル | 変更内容 |
|---------|---------|
| `src/diagram_schema.py` | `Edge.bus_group` フィールド追加 |
| `src/diagram_renderer.py` | 上記全関数の追加・改修。2フェーズ描画パイプライン、auto-bus検出、barycenter法 |
