# Step 6: ネットワーク機器アイコン対応

**日付**: 2026-03-26
**対象ファイル**: `src/diagram_schema.py`, `src/diagram_icons.py`(新規), `src/diagram_renderer.py`, `src/icons/`(新規)

## 実施内容

### 1. DiagramSpec スキーマ拡張
- `Node` dataclass に `icon: Optional[str]` フィールドを追加
- `BUILTIN_ICONS` 定数（15種）を定義
- JSONパーサーが `"icon"` フィールドを読み取り対応

### 2. SVGアイコン作成（15種）
Ciscoネットワークトポロジアイコンスタイルで自作。`src/icons/` に格納。

| アイコン名 | 説明 |
|-----------|------|
| router | 円+交差矢印X（Cisco Classic） |
| switch | 矩形+4方向矢印 |
| server | ラックサーバー（3ベイ+LED） |
| database | シリンダー（上楕円+底弧+側線） |
| cloud | クラウドアウトライン |
| firewall | ブリックウォールパターン |
| client | デスクトップモニター+スタンド |
| internet | 地球儀（赤道+子午線） |
| load_balancer | 入力1→出力3の分岐矢印 |
| wireless_ap | アンテナ+同心円弧 |
| storage | 3段積みディスク |
| printer | プリンター本体+用紙 |
| phone | IP電話ハンドセット |
| vpn | シールド+鍵穴 |
| monitor | 画面+棒グラフ |

**設計仕様**:
- viewBox: 64x64
- stroke-width: 3px（初版2px → 改善で3pxに引き上げ）
- stroke: #1E2761（Midnight Executive navy）
- fill: none（線画のみ）
- stroke-linecap/linejoin: round

### 3. アイコンマネージャー (`diagram_icons.py`)
- `resolve_icon_path()`: ビルトイン名 or ファイルパス → SVGパス解決
- `get_icon_png_path()`: SVG→PNG変換（wand/ImageMagick使用）+ キャッシュ
- `list_builtin_icons()`: 利用可能アイコン一覧
- 変換キャッシュ: `/tmp/diagram_icon_cache/` にハッシュベースで保持

### 4. レンダラー統合
- アイコン付きノードのレイアウト: 上部60%にアイコン画像、下部40%にラベルテキスト
- 透明アンカー矩形をコネクタ接続用に配置
- アイコンなしノードは従来通りの図形描画

## SVG品質改善（v2）
初版のSVGは細すぎ・ディテール過多だったため全面改訂:
- stroke-width: 2px → 3px
- 内部ディテールを簡素化（小サイズ0.5インチでも認識可能に）
- Ciscoオリジナルのシルエットに準拠（router=円+X矢印、firewall=ブリック壁等）

## テスト結果
- 企業ネットワーク構成図（13ノード、12エッジ、3グループ）: OK
- 全15種アイコン一覧（5×3グリッド）: OK

## 今後の改善候補
- アイコンノードの背景カード追加
- icon_ratio / padding の微調整
- ユーザーカスタムアイコンの追加手順ドキュメント
