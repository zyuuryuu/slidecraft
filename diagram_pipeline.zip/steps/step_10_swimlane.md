# Step 10: スイムレーン対応

## 概要

DiagramSpec v1.1 にスイムレーン機能を追加。業務フロー図・シーケンス図の両ユースケースに対応し、TB/BT（縦フロー）とLR/RL（横フロー）の両方向をサポート。

## 1. スキーマ設計

### 設計判断: `lanes[]` をGroupとは独立したトップレベルフィールドとして追加

**理由**:
- Laneはクロス軸全体を横断する「帯」、Groupはノードを囲む「矩形」— 本質的に異なる概念
- レーン内にグループを配置するユースケース（`lane` + `group` 共存）に対応
- レイアウトロジックが根本的に異なる（均等分割 vs BBox算出）

### 追加要素

| 要素 | フィールド | 説明 |
|------|-----------|------|
| `LaneStyle` | `header_fill`, `header_font_color`, `band_fill`, `border`, `border_width` | レーンの視覚スタイル |
| `Lane` | `id`, `label`, `style` | レーン定義 |
| `Node.lane` | Optional[str] | レーン参照（Group参照と共存可能） |
| `DiagramSpec.lanes` | list[Lane] | トップレベルレーンリスト |

### バリデーション

- `Node.lane` が存在しない `Lane.id` を参照 → エラー
- `lanes` が空リスト or 未指定 → 従来通り動作（後方互換）

## 2. レイアウトアルゴリズム (v3)

### 方針

- レーンがクロス軸（TB→X, LR→Y）を比例分割する帯を形成
- 各ノードはレーン帯内でクロス軸方向にセンタリング
- メイン軸の位置はBFS layerで決定（既存ロジック流用）

### 処理フロー

```
1. _assign_layers() + _order_within_layers() でレイヤー算出
2. ノードをレーン別に分類
3. 各レーンのクロス軸サイズを算出（レイヤーあたり最大ノード数で比例配分）
4. レーン帯内でノードをセンタリング配置
5. メイン軸はグローバルlayer位置（自動スケーリング付き）
```

### 方向別動作

| 方向 | レーン配置 | ヘッダー位置 | フロー方向 |
|------|-----------|------------|-----------|
| TB | 縦列（X方向に並ぶ） | 上部横帯 | 上→下 |
| BT | 縦列 | 上部横帯 | 下→上 |
| LR | 横行（Y方向に並ぶ） | 左端縦帯 | 左→右 |
| RL | 横行 | 左端縦帯 | 右→左 |

## 3. レンダリング (`_draw_swimlanes`)

- **帯背景**: 交互色（`#F8FAFC` / `#EFF3F8`）、カスタム可能
- **ヘッダー**: ネイビー背景 + 白文字、幅0.6"
- **区切り線**: レーン間にグレー線

## 4. LR/RL方向のL字ルート

### 変更点

既存のL字ルート発動条件（TB/BT方向のみ）を拡張:

```python
# 旧: TB/BT方向の水平オフセットのみ
use_l_route = is_vertical and h_offset > from_pos.w * 0.3

# 新: LR/RL方向の垂直オフセット（レーンまたぎ）も対象
if not is_vertical:
    v_offset = abs(from_pos.y + from_pos.h/2 - to_pos.y - to_pos.h/2)
    if v_offset > from_pos.h * 0.3:
        use_l_route = True
```

## 5. テスト結果

| テスト | 方向 | 結果 |
|--------|------|------|
| 受注処理フロー（3レーン） | TB | ✓ 縦列レーン正常 |
| 受注処理フロー（3レーン） | LR | ✓ 横行レーン + L字ルート正常 |
| flowchart（レーンなし） | TB | ✓ 後方互換OK |
| network nested subgraph | TB | ✓ 後方互換OK |
| orgchart | TB | ✓ 後方互換OK |

## 変更ファイル

| ファイル | 変更内容 |
|---------|---------|
| `src/diagram_schema.py` | `Lane`, `LaneStyle` 追加、`Node.lane` 追加、バリデーション拡張 |
| `src/diagram_renderer.py` | `_compute_layout_swimlane()`, `_draw_swimlanes()` 追加、LR L字ルート条件拡張 |
| `ARCHITECTURE.md` | v1.1候補・ロードマップをスイムレーン実装済みに更新 |
| `PROJECT_SPEC.md` | step_10 記録追加 |
