# Step 09: CLI実装 + エッジラベル衝突回避

## 概要

diagram_cli.py の実装（ARCHITECTURE.md §4 準拠）と、エッジラベル配置アルゴリズムの設計・実装。

## 1. CLI実装 (diagram_cli.py)

### 対応モード

| モード | コマンド例 | 動作 |
|--------|-----------|------|
| Mode 1 | `python diagram_cli.py input.json -o out.pptx` | JSON→PPTX直接変換 |
| Mode 1b | `python diagram_cli.py input.json --validate-only` | JSONスキーマ検証のみ |
| Mode 2 | `python diagram_cli.py input.mmd -o out.pptx --api-convert` | Mermaid→LLM API→PPTX |
| Mode 3 | `python diagram_cli.py --show-prompt` | システムプロンプト出力 |
| Mode 3b | `python diagram_cli.py --show-prompt --with-mermaid input.mmd` | プロンプト+Mermaid出力 |

### オプション一覧

- `input` — 入力ファイル (.json / .mmd)
- `-o, --output` — 出力PPTXパス (default: diagram_output.pptx)
- `-t, --template` — テンプレートPPTX
- `--theme` — テーマ名 (default: midnight_executive)
- `--api-convert` — Mermaid入力をLLM APIで自動変換
- `--api-provider` — anthropic / openai (default: anthropic)
- `--show-prompt` — システムプロンプト表示
- `--with-mermaid` — --show-prompt時にMermaidも含める
- `--validate-only` — JSON検証のみ

### API変換 (Mode 2)

- 環境変数 `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` が必要
- SDKは動的import（anthropic / openai）
- レスポンスからmarkdownコードブロックを自動除去
- 変換結果をparse_diagram_jsonで検証後レンダリング

### エラーハンドリング

- .mmd入力に --api-convert なし → 3つの解決策を提示
- ファイル不在 → 明確なエラー
- API未設定 → 必要な環境変数を案内
- 不正な拡張子 → .json or .mmd を案内

## 2. エッジラベル衝突回避アルゴリズム (_place_edge_label)

### 設計方針

場当たり的な数値調整ではなく、「候補生成 → 制約判定 → 優先選択」の構造的な方法論。

### アルゴリズム (案A+)

```
1. connector path → segments に分解
2. 優先順位付き候補を生成:
   (a) L字ルートの肘外側（最優先）
   (b) 全セグメントの 1/2, 1/4, 3/4 点 × 法線方向offset × 通常/狭クリアランス
   (c) ワイドオフセット候補（密集エリア向け、ノード完全外側に配置）
3. 各候補に対して制約判定:
   - スライド境界内か
   - ノードBBox（パディング付き）と衝突しないか
4. 最初の合格候補を採用
5. 全候補不合格 → 最初の候補をスライド内にclamp
```

### 主要パラメータ

| パラメータ | 値 | 用途 |
|-----------|-----|------|
| `_CLR_NORMAL` | 0.08" | 通常クリアランス |
| `_CLR_TIGHT` | 0.03" | 密集エリア用狭クリアランス |
| `_NODE_PAD` | 0.06" | ノードBBox衝突判定パディング |
| `_MARGIN` | 0.05" | スライド端マージン |

### 解決した問題

1. **ノード間の隙間にラベルが挟まる** — BBoxパディングにより「接触≒衝突」として扱う
2. **スライド外にはみ出す** — スライド境界チェック追加
3. **ラベル幅 > ノード幅の密集エリア** — ワイドオフセット候補がノード完全外側に配置

## テスト結果

| テスト | Mode | 結果 |
|--------|------|------|
| JSON→PPTX | Mode 1 | ✓ flowchart正常生成 |
| --validate-only | Mode 1b | ✓ スキーマ情報正常表示 |
| .mmd without --api-convert | エラー | ✓ 3解決策提示 |
| --show-prompt | Mode 3 | ✓ プロンプト全文出力 |
| --show-prompt --with-mermaid | Mode 3b | ✓ プロンプト+Mermaid出力 |
| --help | — | ✓ ヘルプ表示 |
| replicationラベル配置 | — | ✓ ノード左側に回避配置 |

## 変更ファイル

| ファイル | 変更内容 |
|---------|---------|
| `src/diagram_cli.py` | **新規** — CLI全3モード実装 |
| `src/diagram_renderer.py` | `_place_edge_label()`, `_bbox_overlap()` 追加 |
| `ARCHITECTURE.md` | 「未実装」表記削除、ロードマップ更新 |
| `PROJECT_SPEC.md` | step_09 記録追加 |
| `DIAGRAM_PIPELINE_SPEC.md` | 既知制限 #4, #5 を対応済みに更新 |
