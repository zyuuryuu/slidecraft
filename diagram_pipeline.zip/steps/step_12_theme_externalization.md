# Step 12: テーマ外部ファイル化

## 概要

`ThemeConfig` をYAMLファイルから読み込み可能にし、部分指定マージ方式でカスタムテーマを作成できるようにした。CLIに `--theme` 引数を追加。

## 1. 設計方針

### 形式: YAML
- 人間が直接編集する用途 → コメント対応のYAMLが最適
- `pyyaml` は既にインストール済み（追加依存なし）

### 部分指定マージ
- 指定された項目だけがデフォルト（Midnight Executive）を上書き
- 省略された項目はすべてデフォルト値を継承
- 最小テーマファイル例: `name` + `palette` の数色だけでOK

### node_defaults のマージ戦略
- diagram_type (flowchart/network/orgchart) → role (terminal/process等) の2階層
- role単位で**置換**（role内の個別プロパティのdeep mergeはしない）
- 言及されていないroleはデフォルトを保持

## 2. 実装

### `diagram_theme.py` への追加

| 関数/メソッド | 役割 |
|-------------|------|
| `_dataclass_to_dict(obj)` | dataclass → dict 変換 |
| `_merge_dataclass(base, overrides)` | dataclass の部分上書き（未知キー無視） |
| `_merge_node_defaults(base, overrides)` | node_defaults の2階層マージ |
| `ThemeConfig.from_yaml(path)` | YAML読み込み → DEFAULT上にマージ |
| `ThemeConfig.to_yaml(path)` | 現在の設定をYAMLに書き出し（リファレンス用） |

### CLI `--theme` 引数

```
python diagram_cli.py input.json -o output.pptx --theme themes/my_theme.yaml
```

テーマ解決の優先順位:
1. "midnight_executive" → `DEFAULT_THEME`（ハードコード）
2. 指定パスがファイルとして存在 → `ThemeConfig.from_yaml(path)`
3. `themes/` ディレクトリ内を検索（`themes/{name}`, `themes/{name}.yaml`）
4. 見つからない → エラー

### ファイル配置

```
themes/
├── midnight_executive.yaml   # フルリファレンス（全フィールド記載）
└── example_custom.yaml       # カスタムサンプル（部分指定 + コメント付き）
```

## 3. テーマYAMLの構造

```yaml
name: "テーマ名"

palette:          # 6桁hex（# なし）
  navy: "1E2761"
  accent: "3B82F6"
  # ...

fonts:
  heading: "Georgia"
  body: "Calibri"
  mono: "Consolas"

diagram_style:    # レンダリングレベルのデフォルト
  title_font_size: 20
  edge_color: "#94A3B8"
  # ...

node_defaults:    # diagram_type → role → style props
  flowchart:
    terminal:
      fill: "#3B82F6"
      font_color: "#FFFFFF"
    # ...
```

## 4. テスト結果

| テスト | 結果 |
|--------|------|
| to_yaml でフルリファレンス出力 | ✓ |
| from_yaml 部分指定（palette + fonts のみ） | ✓ 指定項目上書き、他はデフォルト |
| from_yaml node_defaults 部分マージ | ✓ 指定roleのみ置換、他は保持 |
| from_yaml 空YAML → デフォルト返却 | ✓ |
| from_yaml 不正構造 → ValueError | ✓ |
| CLI --theme デフォルト（指定なし） | ✓ |
| CLI --theme YAMLファイルパス | ✓ テーマ名表示 |
| CLI --theme 存在しないファイル → エラー | ✓ |

## 変更ファイル

| ファイル | 変更内容 |
|---------|---------|
| `src/diagram_theme.py` | `from_yaml()`, `to_yaml()`, マージユーティリティ追加 |
| `src/diagram_cli.py` | `--theme` 引数対応、`_resolve_theme()` 追加、Mode 1/2 でテーマをレンダラーに渡す |
| `themes/midnight_executive.yaml` | フルリファレンスYAML（新規） |
| `themes/example_custom.yaml` | カスタムサンプル（新規） |
