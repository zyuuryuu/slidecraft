#!/usr/bin/env python3
"""Rename all placeholder display names in create_30_layouts.py."""

import re

SOURCE = '/sessions/stoic-zealous-fermi/create_30_layouts.py'

# Map: (line_number, old_name_string, new_name_string)
# Line numbers from grep output of xml_ph() calls
RENAMES = [
    # === Shared helpers ===
    # _header_bar
    (246, "'Title'", "'SlideTitle.Header'"),
    (249, "'Subtitle'", "'SlideSubtitle.Header'"),
    # _slide_num
    (255, "'SlideNum'", "'SlideNum.Footer'"),

    # === L00 Title.1Title.Single ===
    (272, "'Label'", "'CategoryLabel.Top'"),
    (275, "'Title'", "'Title.Center'"),
    (278, "'Subtitle'", "'Subtitle.Center'"),
    (281, "'Date'", "'Date.Bottom'"),
    (284, "'Footer'", "'Footer.Bottom'"),

    # === L01 Title.1Title.Single+1Meta ===
    (296, "'Label'", "'CategoryLabel.Top'"),
    (299, "'Title'", "'Title.Left'"),
    (302, "'Subtitle'", "'Subtitle.Left'"),
    (305, "'Meta'", "'Meta.Right'"),
    (309, "'Footer'", "'Footer.Bottom'"),

    # === L02 Title.1Title.Single+1Summary ===
    (321, "'Label'", "'CategoryLabel.Left'"),
    (324, "'Title'", "'Title.Left'"),
    (327, "'Subtitle'", "'Subtitle.Left'"),
    (330, "'RightContent'", "'Summary.Right'"),
    (334, "'Date'", "'Date.Bottom'"),

    # === L03 Section.1Title.Single ===
    (348, "'Label'", "'SectionLabel.Top'"),
    (351, "'Title'", "'Title.Center'"),
    (354, "'Desc'", "'Description.Bottom'"),

    # === L04 SectionNav.1Title.Single ===
    (365, "'Number'", "'SectionNumber.Left'"),
    (368, "'NumLabel'", "'SectionLabel.Left'"),
    (371, "'Title'", "'Title.Right'"),
    (374, "'Desc'", "'Description.Right'"),

    # === L05 SectionBreak.1Title.Single ===
    (387, "'Label'", "'SectionLabel.Top'"),
    (390, "'Title'", "'Title.Center'"),
    (393, "'Desc'", "'Description.Bottom'"),

    # === L06 Content.1Body.Single ===
    (405, "'Body'", "'Body.Center'"),

    # === L07 Content.1Body.Single+1Notes ===
    (417, "'Body'", "'Body.Left'"),
    (420, "'Sidebar'", "'Notes.Right'"),

    # === L08 Content.1Body.Single+1Source ===
    (432, "'Body'", "'Body.Center'"),
    (435, "'Source'", "'Source.Bottom'"),

    # === L09 Content.1Body.Single+1Callout ===
    (449, "'CalloutText'", "'Callout.Top'"),
    (453, "'Body'", "'Body.Center'"),

    # === L10 Column.2Body.Equal ===
    (466, "'Left'", "'Body1.Left'"),
    (469, "'Right'", "'Body2.Right'"),

    # === L11 Column.2Body.MainSub ===
    (479, "'Left'", "'Body1.Left'"),
    (484, "'Right'", "'Body2.Right'"),

    # === L12 Column.3Body.Equal ===
    (494, "'Col1'", "'Body1.Left'"),
    (497, "'Col2'", "'Body2.Center'"),
    (500, "'Col3'", "'Body3.Right'"),

    # === L13 KPI.1Value.Single ===
    (516, "'BigNum'", "'Value.Center'"),
    (519, "'StatLabel'", "'ValueLabel.Center'"),
    (522, "'StatDesc'", "'ValueDesc.Center'"),

    # === L14 KPI.2Value.Equal ===
    (538, "'Num1'", "'Value1.Left'"),
    (541, "'Label1'", "'ValueLabel1.Left'"),
    (545, "'Num2'", "'Value2.Right'"),
    (548, "'Label2'", "'ValueLabel2.Right'"),

    # === L15 KPI.3Value.Equal ===
    (568, "'Num1'", "'Value1.Left'"),
    (571, "'Desc1'", "'ValueLabel1.Left'"),
    (574, "'Num2'", "'Value2.Center'"),
    (577, "'Desc2'", "'ValueLabel2.Center'"),
    (580, "'Num3'", "'Value3.Right'"),
    (583, "'Desc3'", "'ValueLabel3.Right'"),

    # === L16 KPI.4Value.Grid ===
    (609, "'Stat1'", "'Value1.TopLeft'"),
    (613, "'Stat2'", "'Value2.TopRight'"),
    (617, "'Stat3'", "'Value3.BottomLeft'"),
    (621, "'Stat4'", "'Value4.BottomRight'"),

    # === L17 Chart.1Chart.Single ===
    (637, "'Chart'", "'Body.Center'"),

    # === L18 Chart.1Chart.Single+1Analysis ===
    (650, "'Chart'", "'Body.Left'"),
    (654, "'Analysis'", "'Analysis.Right'"),

    # === L19 Chart.2Chart.Equal ===
    (669, "'Left'", "'Body1.Left'"),
    (673, "'Right'", "'Body2.Right'"),

    # === L20 Table.1Table.Single+1Source ===
    (687, "'Table'", "'Body.Center'"),
    (691, "'Source'", "'Source.Bottom'"),

    # === L21 Table.1Table.Single+1Notes ===
    (701, "'Table'", "'Body.Left'"),
    (708, "'Notes'", "'Notes.Right'"),

    # === L22 Compare.2Option.Versus ===
    (729, "'LabelL'", "'OptionLabel1.Left'"),
    (732, "'ContentL'", "'OptionContent1.Left'"),
    (735, "'LabelR'", "'OptionLabel2.Right'"),
    (738, "'ContentR'", "'OptionContent2.Right'"),

    # === L23 Compare.1Matrix.Single ===
    # (no placeholders besides header bar)

    # === L24 Process.4Step.Sequential ===
    (768, "'Step1'", "'Step1.Left'"),
    (772, "'Step2'", "'Step2.CenterLeft'"),
    (776, "'Step3'", "'Step3.CenterRight'"),
    (780, "'Step4'", "'Step4.Right'"),

    # === L25 Process.3Step.Sequential ===
    (798, "'Step1'", "'Step1.Top'"),
    (802, "'Step2'", "'Step2.Center'"),
    (806, "'Step3'", "'Step3.Bottom'"),

    # === L26 Summary.1Agenda.Single ===
    (822, "'Title'", "'Title.Left'"),
    (825, "'SubInfo'", "'MeetingInfo.Left'"),
    (829, "'Items'", "'AgendaItems.Right'"),

    # === L27 Summary.2Block.Equal ===
    (844, "'Findings'", "'Body1.Left'"),
    (848, "'Recommendations'", "'Body2.Right'"),

    # === L28 Closing.1Message.Single ===
    (864, "'Label'", "'CategoryLabel.Top'"),
    (867, "'Title'", "'Title.Center'"),
    (870, "'Name'", "'PresenterName.Bottom'"),
    (873, "'Contact'", "'Contact.Bottom'"),

    # === L29 Closing.1Steps.Single+1Notes ===
    (888, "'Title'", "'Title.Left'"),
    (891, "'Steps'", "'ActionSteps.Left'"),
    (895, "'CTA'", "'Notes.Right'"),
]

with open(SOURCE, 'r') as f:
    lines = f.readlines()

applied = 0
errors = []

for target_line, old_name, new_name in RENAMES:
    idx = target_line - 1  # 0-indexed
    if idx < 0 or idx >= len(lines):
        errors.append(f"Line {target_line}: out of range")
        continue

    line = lines[idx]
    if old_name in line:
        # Replace only the first occurrence on this line (the name argument)
        lines[idx] = line.replace(old_name, new_name, 1)
        applied += 1
    else:
        # Check nearby lines (±2) for the string
        found = False
        for offset in [-1, 1, -2, 2]:
            check_idx = idx + offset
            if 0 <= check_idx < len(lines) and old_name in lines[check_idx]:
                lines[check_idx] = lines[check_idx].replace(old_name, new_name, 1)
                applied += 1
                found = True
                print(f"  ⚠ Line {target_line}: found at line {check_idx + 1} instead")
                break
        if not found:
            errors.append(f"Line {target_line}: {old_name} not found (nearby search also failed)")

with open(SOURCE, 'w') as f:
    f.writelines(lines)

print(f"\n✅ Applied {applied}/{len(RENAMES)} renames")
if errors:
    print(f"\n❌ Errors ({len(errors)}):")
    for e in errors:
        print(f"  {e}")
else:
    print("No errors!")
