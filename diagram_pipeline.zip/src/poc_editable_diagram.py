#!/usr/bin/env python3
"""
PoC: Editable vector diagrams in PPTX using python-pptx shapes + connectors.

Tests:
1. Can we create shapes with text that are editable in PowerPoint?
2. Can we create connectors that snap to shapes (move when shapes move)?
3. Can we style shapes to match Midnight Executive theme?
4. Do shapes remain fully editable (not flattened/rasterized)?
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR_TYPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from lxml import etree
import math

_a = 'http://schemas.openxmlformats.org/drawingml/2006/main'
_ns = {'a': _a}

# Midnight Executive palette
C = {
    'navy':       RGBColor(0x1E, 0x27, 0x61),
    'dark_navy':  RGBColor(0x14, 0x1B, 0x41),
    'ice_blue':   RGBColor(0xCA, 0xDC, 0xFC),
    'white':      RGBColor(0xFF, 0xFF, 0xFF),
    'light_gray': RGBColor(0xF5, 0xF7, 0xFA),
    'panel_gray': RGBColor(0xED, 0xF0, 0xF7),
    'dark_text':  RGBColor(0x1E, 0x29, 0x3B),
    'accent':     RGBColor(0x3B, 0x82, 0xF6),
    'teal':       RGBColor(0x06, 0xB6, 0xD4),
    'amber':      RGBColor(0xF5, 0x9E, 0x0B),
    'soft_navy':  RGBColor(0x2D, 0x3A, 0x6E),
    'card_bg':    RGBColor(0xF0, 0xF4, 0xFF),
    'mid_gray':   RGBColor(0x94, 0xA3, 0xB8),
}


def style_shape(shape, fill_color, border_color=None, border_width=Pt(1.5),
                text='', font_size=10, font_color=None, font_bold=False,
                font_name='Calibri', text_align=PP_ALIGN.CENTER):
    """Apply consistent styling to a shape."""
    # Fill
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color

    # Border
    if border_color:
        shape.line.color.rgb = border_color
        shape.line.width = border_width
    else:
        shape.line.fill.background()  # no border

    # Text
    if text:
        tf = shape.text_frame
        tf.word_wrap = True
        tf.auto_size = None
        # Vertical centering
        tf.paragraphs[0].alignment = text_align

        for para in tf.paragraphs:
            for run in para.runs:
                run.font.size = Pt(font_size)
                run.font.color.rgb = font_color or C['white']
                run.font.bold = font_bold
                run.font.name = font_name

        if not tf.paragraphs[0].runs:
            tf.paragraphs[0].text = text
            for run in tf.paragraphs[0].runs:
                run.font.size = Pt(font_size)
                run.font.color.rgb = font_color or C['white']
                run.font.bold = font_bold
                run.font.name = font_name


def _cp_coords(shape, cp_idx):
    """Return (x_emu, y_emu) for a connection-point on any shape.

    For diamonds, cp indices reference the actual vertices, not the
    bounding-box midpoints that python-pptx would use.

    Standard cp mapping (rect / rounded_rect / oval / diamond):
        0 = top center      (diamond: top vertex)
        1 = right center    (diamond: right vertex)
        2 = bottom center   (diamond: bottom vertex)
        3 = left center     (diamond: left vertex)
    """
    l, t, w, h = shape.left, shape.top, shape.width, shape.height
    cx, cy = l + w // 2, t + h // 2

    # Check if diamond via preset geometry name
    is_diamond = False
    try:
        prst = shape._element.spPr.prstGeom.attrib.get('prst', '')
        is_diamond = (prst == 'diamond')
    except Exception:
        pass

    if is_diamond:
        # Vertices
        return {0: (cx, t), 1: (l + w, cy), 2: (cx, t + h), 3: (l, cy)}[cp_idx]
    else:
        # Bounding-box edge midpoints
        return {0: (cx, t), 1: (l + w, cy), 2: (cx, t + h), 3: (l, cy)}[cp_idx]


def add_connector(slide, shape_a, shape_b, connector_type=MSO_CONNECTOR_TYPE.STRAIGHT,
                  color=None, width=Pt(1.5), begin_cp=None, end_cp=None,
                  snap=True):
    """Add a connector between two shapes.

    Connection point indices:
        0 = top center, 1 = right center, 2 = bottom center, 3 = left center

    If snap=True (default), uses begin_connect/end_connect so the connector
    moves when shapes are moved in PowerPoint.
    If snap=False, positions the connector at exact cp coordinates but does
    NOT snap to shapes — useful when python-pptx routing fails (e.g. diamonds).
    """
    # Auto-detect best connection points if not specified
    if begin_cp is None or end_cp is None:
        ax = shape_a.left + shape_a.width // 2
        ay = shape_a.top + shape_a.height // 2
        bx = shape_b.left + shape_b.width // 2
        by = shape_b.top + shape_b.height // 2
        dx, dy = bx - ax, by - ay
        if abs(dx) > abs(dy):
            begin_cp, end_cp = (1, 3) if dx > 0 else (3, 1)
        else:
            begin_cp, end_cp = (2, 0) if dy > 0 else (0, 2)

    # Calculate exact endpoint coordinates
    x1, y1 = _cp_coords(shape_a, begin_cp)
    x2, y2 = _cp_coords(shape_b, end_cp)

    connector = slide.shapes.add_connector(
        connector_type, x1, y1, x2, y2
    )

    if snap:
        try:
            connector.begin_connect(shape_a, begin_cp)
            connector.end_connect(shape_b, end_cp)
        except Exception as e:
            print(f"  ⚠ Snap-to failed ({shape_a.name}→{shape_b.name}): {e}")

    # Style
    connector.line.color.rgb = color or C['mid_gray']
    connector.line.width = width

    return connector


def set_arrow(connector, end='tail', arrow_type='arrow'):
    """Add an arrowhead to a connector via OOXML.

    end: 'tail' (end of line, default) or 'head' (start of line)
    arrow_type: 'arrow', 'triangle', 'stealth', 'diamond', 'oval', 'none'
    """
    ln = connector._element.find(f'.//{{{_a}}}ln')
    if ln is None:
        sp_pr = connector._element.find(f'.//{{{_a}}}..') or connector._element
        ln = connector._element.find(f'.//p:spPr/{{{_a}}}ln',
                                      {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'})
    if ln is None:
        return
    tag = f'{{{_a}}}tailEnd' if end == 'tail' else f'{{{_a}}}headEnd'
    existing = ln.find(tag)
    if existing is not None:
        ln.remove(existing)
    el = etree.SubElement(ln, tag)
    el.set('type', arrow_type)
    el.set('w', 'med')
    el.set('len', 'med')


def add_zone_rect(slide, x, y, w, h, label, border_color, label_color=None):
    """Add a transparent grouping zone rectangle with a label in top-left."""
    zone = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(x), Inches(y), Inches(w), Inches(h)
    )
    zone.fill.background()  # transparent
    zone.line.color.rgb = border_color
    zone.line.width = Pt(1.5)
    zone.line.dash_style = 2  # dash

    # Label in top-left
    lbl = slide.shapes.add_textbox(
        Inches(x + 0.1), Inches(y + 0.05), Inches(1.5), Inches(0.3)
    )
    p = lbl.text_frame.paragraphs[0]
    p.text = label
    p.font.size = Pt(8)
    p.font.bold = True
    p.font.color.rgb = label_color or border_color
    return zone


# ═══════════════════════════════════════
# TEST 1: Simple Network Diagram
# ═══════════════════════════════════════

def test_network_diagram(prs):
    """Create a simple network topology: Router → Switch → 3 Servers."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank layout

    # Title
    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(10), Inches(0.5))
    tf = txBox.text_frame
    tf.paragraphs[0].text = "Test 1: Network Diagram (Editable Shapes + Connectors)"
    tf.paragraphs[0].font.size = Pt(20)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = C['navy']

    # --- Nodes ---
    # Internet cloud (rounded rect as proxy)
    internet = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(5.5), Inches(0.8), Inches(2.0), Inches(0.8)
    )
    style_shape(internet, C['mid_gray'], C['dark_text'], text='Internet',
                font_size=11, font_bold=True)

    # Firewall
    firewall = slide.shapes.add_shape(
        MSO_SHAPE.DIAMOND,
        Inches(5.7), Inches(2.0), Inches(1.6), Inches(1.0)
    )
    style_shape(firewall, C['amber'], text='Firewall',
                font_size=9, font_bold=True, font_color=C['dark_text'])

    # Router
    router = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(5.5), Inches(3.5), Inches(2.0), Inches(0.8)
    )
    style_shape(router, C['navy'], C['accent'], text='Core Router',
                font_size=11, font_bold=True)

    # Switches
    sw1 = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(2.0), Inches(4.8), Inches(1.8), Inches(0.7)
    )
    style_shape(sw1, C['soft_navy'], C['accent'], text='Switch-A',
                font_size=10, font_bold=True)

    sw2 = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(5.5), Inches(4.8), Inches(1.8), Inches(0.7)
    )
    style_shape(sw2, C['soft_navy'], C['accent'], text='Switch-B',
                font_size=10, font_bold=True)

    sw3 = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(9.0), Inches(4.8), Inches(1.8), Inches(0.7)
    )
    style_shape(sw3, C['soft_navy'], C['accent'], text='Switch-C',
                font_size=10, font_bold=True)

    # Servers
    servers = []
    for i, (x, label) in enumerate([
        (1.5, 'Web-01'), (2.8, 'Web-02'),
        (5.0, 'App-01'), (6.3, 'App-02'),
        (8.5, 'DB-01'), (9.8, 'DB-02'),
    ]):
        srv = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE,
            Inches(x), Inches(6.0), Inches(1.1), Inches(0.6)
        )
        color = [C['accent'], C['accent'], C['teal'], C['teal'], C['navy'], C['navy']][i]
        style_shape(srv, color, text=label, font_size=9, font_bold=True)
        servers.append(srv)

    # --- Zone grouping rectangles ---
    add_zone_rect(slide, 4.8, 0.6, 3.4, 1.2, 'External', C['mid_gray'])
    add_zone_rect(slide, 4.8, 1.85, 3.4, 1.35, 'DMZ', C['amber'])
    add_zone_rect(slide, 4.6, 3.3, 3.2, 1.0, 'Core', C['accent'])
    add_zone_rect(slide, 1.3, 4.55, 4.7, 1.1, 'Access Layer', C['teal'])
    add_zone_rect(slide, 8.3, 4.55, 3.2, 1.1, 'Access Layer', C['teal'])
    add_zone_rect(slide, 1.0, 5.8, 5.6, 1.0, 'Server Farm', C['navy'])
    add_zone_rect(slide, 8.0, 5.8, 3.8, 1.0, 'Server Farm', C['navy'])

    # --- Connectors (all vertical hierarchy: bottom→top) ---
    add_connector(slide, internet, firewall, color=C['mid_gray'], width=Pt(2),
                  begin_cp=2, end_cp=0)
    add_connector(slide, firewall, router, color=C['mid_gray'], width=Pt(2),
                  begin_cp=2, end_cp=0)
    add_connector(slide, router, sw1, color=C['accent'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)
    add_connector(slide, router, sw2, color=C['accent'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)
    add_connector(slide, router, sw3, color=C['accent'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)

    # Switch to servers (bottom→top)
    add_connector(slide, sw1, servers[0], color=C['teal'], width=Pt(1),
                  begin_cp=2, end_cp=0)
    add_connector(slide, sw1, servers[1], color=C['teal'], width=Pt(1),
                  begin_cp=2, end_cp=0)
    add_connector(slide, sw2, servers[2], color=C['teal'], width=Pt(1),
                  begin_cp=2, end_cp=0)
    add_connector(slide, sw2, servers[3], color=C['teal'], width=Pt(1),
                  begin_cp=2, end_cp=0)
    add_connector(slide, sw3, servers[4], color=C['teal'], width=Pt(1),
                  begin_cp=2, end_cp=0)
    add_connector(slide, sw3, servers[5], color=C['teal'], width=Pt(1),
                  begin_cp=2, end_cp=0)

    print("  ✓ Network diagram created")


# ═══════════════════════════════════════
# TEST 2: Operation Flow Diagram
# ═══════════════════════════════════════

def test_flow_diagram(prs):
    """Create a simple operation flow with decision points."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(10), Inches(0.5))
    tf = txBox.text_frame
    tf.paragraphs[0].text = "Test 2: Operation Flow Diagram (Editable)"
    tf.paragraphs[0].font.size = Pt(20)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = C['navy']

    # Start (rounded rect / pill)
    start = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(5.5), Inches(0.9), Inches(2.0), Inches(0.6)
    )
    style_shape(start, C['accent'], text='開始', font_size=12, font_bold=True)

    # Process 1
    proc1 = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(5.2), Inches(1.9), Inches(2.6), Inches(0.7)
    )
    style_shape(proc1, C['navy'], C['accent'], Pt(1),
                text='リクエスト受付', font_size=11, font_bold=True)

    # Decision
    decision = slide.shapes.add_shape(
        MSO_SHAPE.DIAMOND,
        Inches(5.3), Inches(3.0), Inches(2.4), Inches(1.2)
    )
    style_shape(decision, C['amber'], text='認証OK？',
                font_size=10, font_bold=True, font_color=C['dark_text'])

    # Yes path — vertically centered with diamond (diamond center_y = 3.0 + 0.6 = 3.6)
    proc_yes = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(9.0), Inches(3.25), Inches(2.4), Inches(0.7)
    )
    style_shape(proc_yes, C['navy'], C['accent'], Pt(1),
                text='データ処理', font_size=11, font_bold=True)

    # No path — vertically centered with diamond
    proc_no = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(1.5), Inches(3.25), Inches(2.4), Inches(0.7)
    )
    style_shape(proc_no, C['soft_navy'], text='エラー返却',
                font_size=11, font_bold=True)

    # Response
    proc_resp = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(9.0), Inches(4.5), Inches(2.4), Inches(0.7)
    )
    style_shape(proc_resp, C['navy'], C['accent'], Pt(1),
                text='レスポンス生成', font_size=11, font_bold=True)

    # End
    end = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(5.5), Inches(5.8), Inches(2.0), Inches(0.6)
    )
    style_shape(end, C['teal'], text='終了', font_size=12, font_bold=True)

    # Labels for decision branches
    yes_label = slide.shapes.add_textbox(Inches(7.9), Inches(3.35), Inches(0.6), Inches(0.4))
    yes_label.text_frame.paragraphs[0].text = "Yes"
    yes_label.text_frame.paragraphs[0].font.size = Pt(10)
    yes_label.text_frame.paragraphs[0].font.bold = True
    yes_label.text_frame.paragraphs[0].font.color.rgb = C['accent']

    no_label = slide.shapes.add_textbox(Inches(4.3), Inches(3.35), Inches(0.6), Inches(0.4))
    no_label.text_frame.paragraphs[0].text = "No"
    no_label.text_frame.paragraphs[0].font.size = Pt(10)
    no_label.text_frame.paragraphs[0].font.bold = True
    no_label.text_frame.paragraphs[0].font.color.rgb = C['amber']

    # ── Connectors (all with arrowheads for workflow direction) ──
    # Helper: draw a plain line between two (x, y) EMU coordinates
    def add_line_xy(x1, y1, x2, y2, color=C['mid_gray'], width=Pt(1.5), arrow=False):
        conn = slide.shapes.add_connector(
            MSO_CONNECTOR_TYPE.STRAIGHT, x1, y1, x2, y2
        )
        conn.line.color.rgb = color
        conn.line.width = width
        if arrow:
            set_arrow(conn)
        return conn

    # Vertical flow
    c = add_connector(slide, start, proc1,
                      color=C['mid_gray'], width=Pt(2),
                      begin_cp=2, end_cp=0)
    set_arrow(c)

    c = add_connector(slide, proc1, decision,
                      color=C['mid_gray'], width=Pt(2),
                      begin_cp=2, end_cp=0)
    set_arrow(c)

    # Diamond horizontal branches
    c = add_connector(slide, decision, proc_yes,
                      color=C['accent'], width=Pt(2),
                      begin_cp=1, end_cp=3, snap=False)
    set_arrow(c)

    c = add_connector(slide, decision, proc_no,
                      color=C['amber'], width=Pt(2),
                      begin_cp=3, end_cp=1, snap=False)
    set_arrow(c)

    # Vertical continuation after Yes
    c = add_connector(slide, proc_yes, proc_resp,
                      color=C['accent'], width=Pt(2),
                      begin_cp=2, end_cp=0)
    set_arrow(c)

    # Merge paths to end — L-shaped routing (vertical then horizontal)
    # proc_no: bottom → down → right to end's left
    no_bx, no_by = _cp_coords(proc_no, 2)
    end_lx, end_ly = _cp_coords(end, 3)
    end_cy = end.top + end.height // 2
    add_line_xy(no_bx, no_by, no_bx, end_cy,
                color=C['mid_gray'], width=Pt(1.5))
    add_line_xy(no_bx, end_cy, end_lx, end_cy,
                color=C['mid_gray'], width=Pt(1.5), arrow=True)

    # proc_resp: bottom → down → left to end's right
    resp_bx, resp_by = _cp_coords(proc_resp, 2)
    end_rx, end_ry = _cp_coords(end, 1)
    add_line_xy(resp_bx, resp_by, resp_bx, end_cy,
                color=C['mid_gray'], width=Pt(1.5))
    add_line_xy(resp_bx, end_cy, end_rx, end_cy,
                color=C['mid_gray'], width=Pt(1.5), arrow=True)

    print("  ✓ Flow diagram created")


# ═══════════════════════════════════════
# TEST 3: Organization Chart
# ═══════════════════════════════════════

def test_org_chart(prs):
    """Create a simple org chart hierarchy."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    txBox = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(10), Inches(0.5))
    tf = txBox.text_frame
    tf.paragraphs[0].text = "Test 3: Organization Chart (Editable)"
    tf.paragraphs[0].font.size = Pt(20)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = C['navy']

    def org_node(x, y, w, h, title, name, color=C['navy'], border=C['accent']):
        shape = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(x), Inches(y), Inches(w), Inches(h)
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = color
        shape.line.color.rgb = border
        shape.line.width = Pt(1.5)

        tf = shape.text_frame
        tf.word_wrap = True

        # Title line
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(8)
        p.font.color.rgb = C['ice_blue']
        p.font.bold = False
        p.alignment = PP_ALIGN.CENTER

        # Name line
        p2 = tf.add_paragraph()
        p2.text = name
        p2.font.size = Pt(12)
        p2.font.color.rgb = C['white']
        p2.font.bold = True
        p2.font.name = 'Georgia'
        p2.alignment = PP_ALIGN.CENTER

        return shape

    # Layout constants — 6 teams, each 1.7" wide, 0.3" gap
    TW = 1.7   # team node width
    TG = 0.3   # gap between team nodes
    step = TW + TG  # 2.0"
    t_x0 = 0.9  # first team left x  → last right edge: 0.9 + 6*1.7 + 5*0.3 = 12.6

    # Team x positions
    tx = [t_x0 + i * step for i in range(6)]
    # VP centers: average of their children's centers
    def vp_x(i1, i2):
        return (tx[i1] + TW/2 + tx[i2] + TW/2) / 2

    VPW = 2.2  # VP node width

    # CEO
    ceo_cx = (tx[0] + TW/2 + tx[5] + TW/2) / 2
    ceo = org_node(ceo_cx - 1.3, 0.9, 2.6, 0.9, 'CEO', '田中 太郎', C['dark_navy'], C['accent'])

    # VPs (centered over their children)
    vp1 = org_node(vp_x(0, 1) - VPW/2, 2.5, VPW, 0.9, 'VP of Engineering', '鈴木 花子', C['navy'], C['accent'])
    vp2 = org_node(vp_x(2, 3) - VPW/2, 2.5, VPW, 0.9, 'VP of Sales', '佐藤 次郎', C['navy'], C['teal'])
    vp3 = org_node(vp_x(4, 5) - VPW/2, 2.5, VPW, 0.9, 'VP of Operations', '山田 美咲', C['navy'], C['amber'])

    # Teams (evenly spaced, no overlap)
    t1 = org_node(tx[0], 4.2, TW, 0.8, 'Backend Team', '高橋 一郎', C['soft_navy'], C['accent'])
    t2 = org_node(tx[1], 4.2, TW, 0.8, 'Frontend Team', '伊藤 真理', C['soft_navy'], C['accent'])
    t3 = org_node(tx[2], 4.2, TW, 0.8, 'Japan Sales', '渡辺 健太', C['soft_navy'], C['teal'])
    t4 = org_node(tx[3], 4.2, TW, 0.8, 'Global Sales', '小林 あい', C['soft_navy'], C['teal'])
    t5 = org_node(tx[4], 4.2, TW, 0.8, 'DevOps', '加藤 翔', C['soft_navy'], C['amber'])
    t6 = org_node(tx[5], 4.2, TW, 0.8, 'QA', '松本 由美', C['soft_navy'], C['amber'])

    # Connectors: all hierarchy = parent.bottom(2) → child.top(0)
    add_connector(slide, ceo, vp1, color=C['accent'], width=Pt(2),
                  begin_cp=2, end_cp=0)
    add_connector(slide, ceo, vp2, color=C['teal'], width=Pt(2),
                  begin_cp=2, end_cp=0)
    add_connector(slide, ceo, vp3, color=C['amber'], width=Pt(2),
                  begin_cp=2, end_cp=0)

    # VP1 → Teams
    add_connector(slide, vp1, t1, color=C['accent'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)
    add_connector(slide, vp1, t2, color=C['accent'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)

    # VP2 → Teams
    add_connector(slide, vp2, t3, color=C['teal'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)
    add_connector(slide, vp2, t4, color=C['teal'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)

    # VP3 → Teams
    add_connector(slide, vp3, t5, color=C['amber'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)
    add_connector(slide, vp3, t6, color=C['amber'], width=Pt(1.5),
                  begin_cp=2, end_cp=0)

    print("  ✓ Org chart created")


# ═══════════════════════════════════════
# MAIN
# ═══════════════════════════════════════

if __name__ == '__main__':
    print("Creating PoC: Editable Diagrams...")

    prs = Presentation()
    prs.slide_width = Emu(12192000)   # 13.333"
    prs.slide_height = Emu(6858000)   # 7.5"

    test_network_diagram(prs)
    test_flow_diagram(prs)
    test_org_chart(prs)

    out_path = '/sessions/stoic-zealous-fermi/mnt/presentations/PoC_Editable_Diagrams.pptx'
    prs.save(out_path)
    print(f"\n✅ Saved: {out_path}")
    print("   Please verify in PowerPoint/preview that shapes are editable")
