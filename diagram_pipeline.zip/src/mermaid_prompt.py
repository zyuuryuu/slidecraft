"""
Mermaid → DiagramSpec JSON conversion prompt builder.

Loads prompt template and few-shot examples from external files
in the prompts/ directory, then assembles them into an LLM-ready
messages list.

Files:
    prompts/mermaid_system_prompt.txt  — System prompt template
    prompts/mermaid_examples.json      — Few-shot examples (input/output)

Usage:
    from mermaid_prompt import build_conversion_prompt, get_system_prompt
    messages = build_conversion_prompt(mermaid_text)
"""

from __future__ import annotations
import json
from pathlib import Path
from diagram_theme import ThemeConfig, DEFAULT_THEME


# ══════════════════════════════════════════════
# File paths
# ══════════════════════════════════════════════

_PROMPTS_DIR = Path(__file__).parent / "prompts"
_SYSTEM_PROMPT_PATH = _PROMPTS_DIR / "mermaid_system_prompt.txt"
_EXAMPLES_PATH = _PROMPTS_DIR / "mermaid_examples.json"


# ══════════════════════════════════════════════
# Loaders
# ══════════════════════════════════════════════

def _load_system_prompt_template() -> str:
    """Load the system prompt template from disk."""
    return _SYSTEM_PROMPT_PATH.read_text(encoding="utf-8")


def _load_examples() -> list[dict]:
    """Load few-shot examples from JSON.

    Returns list of dicts with keys: name, input, output (dict).
    """
    return json.loads(_EXAMPLES_PATH.read_text(encoding="utf-8"))


# ══════════════════════════════════════════════
# Prompt Assembly
# ══════════════════════════════════════════════

def get_system_prompt(theme: ThemeConfig = DEFAULT_THEME) -> str:
    """Build the system prompt with theme-specific palette and font info.

    Replaces placeholders in the template:
        {palette_section} — color palette listing
        {heading_font}    — heading font name (e.g. Georgia)
        {body_font}       — body font name (e.g. Calibri)
    """
    template = _load_system_prompt_template()
    return template.format(
        palette_section=theme.palette_summary_for_prompt(),
        heading_font=theme.fonts.heading,
        body_font=theme.fonts.body,
    )


def build_conversion_prompt(mermaid_text: str,
                            theme: ThemeConfig = DEFAULT_THEME) -> list[dict]:
    """Build a messages list for LLM Mermaid→JSON conversion.

    Loads few-shot examples from prompts/mermaid_examples.json and
    appends the user's Mermaid input as the final message.

    Args:
        mermaid_text: Mermaid diagram source text
        theme: ThemeConfig for palette injection into system prompt

    Returns:
        List of message dicts with 'role' and 'content' keys.
    """
    examples = _load_examples()
    messages = []

    for ex in examples:
        messages.append({
            "role": "user",
            "content": f"以下のMermaid図をDiagramSpec JSONに変換してください:\n\n{ex['input']}",
        })
        messages.append({
            "role": "assistant",
            "content": json.dumps(ex["output"], ensure_ascii=False, indent=2),
        })

    messages.append({
        "role": "user",
        "content": f"以下のMermaid図をDiagramSpec JSONに変換してください:\n\n{mermaid_text}",
    })

    return messages


# ══════════════════════════════════════════════
# Self-test
# ══════════════════════════════════════════════

if __name__ == "__main__":
    from diagram_schema import parse_diagram_json

    theme = DEFAULT_THEME

    # Test system prompt loading
    system_prompt = get_system_prompt(theme=theme)
    print(f"✅ System prompt loaded: {len(system_prompt)} chars")
    print(f"   Theme: {theme.name}")
    print(f"   Fonts: heading={theme.fonts.heading}, body={theme.fonts.body}")

    # Test examples loading
    examples = _load_examples()
    print(f"   Examples loaded: {len(examples)}")

    # Test full prompt build
    test_mermaid = "```mermaid\nflowchart LR\n    A[入力] --> B{判定}\n```"
    messages = build_conversion_prompt(test_mermaid, theme=theme)
    print(f"   Prompt built: {len(messages)} messages")

    # Validate example outputs against schema
    for ex in examples:
        json_str = json.dumps(ex["output"], ensure_ascii=False)
        spec = parse_diagram_json(json_str)
        print(f"   Example '{ex['name']}': {len(spec.nodes)} nodes, "
              f"{len(spec.edges)} edges — VALID ✓")
