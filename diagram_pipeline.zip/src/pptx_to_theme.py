#!/usr/bin/env python3
"""pptx_to_theme.py — Extract a ThemeConfig YAML from an existing PPTX file.

Reads the OOXML theme (clrScheme, fontScheme) and scans slide layouts
for dominant colors to produce a best-effort ThemeConfig YAML that can
be used with diagram_cli.py --theme.

Usage:
    python pptx_to_theme.py input.pptx -o themes/extracted.yaml
    python pptx_to_theme.py input.pptx                         # prints to stdout

What is extracted automatically:
    - palette: from clrScheme (12 OOXML theme colors) + layout shape fills
    - fonts:   from fontScheme (major/minor latin typeface)
    - diagram_style.slide_bg: from most common light fill color
    - diagram_style.header_bar_color: from most common dark fill color

What uses defaults (manual tuning expected):
    - node_defaults (flowchart/network/orgchart classDefs)
    - diagram_style fine-grained values (edge_width, label sizes, etc.)

See DETAILED_DESIGN.md §7 for ThemeConfig specification.
"""

from __future__ import annotations

import argparse
import sys
import zipfile
from collections import Counter
from pathlib import Path
from typing import Optional

from lxml import etree
import yaml

# ── Ensure src/ is importable ──
_SRC_DIR = Path(__file__).resolve().parent
if str(_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(_SRC_DIR))


# ══════════════════════════════════════════════
# OOXML namespace helpers
# ══════════════════════════════════════════════

_NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}


def _find_text(elem, xpath: str) -> Optional[str]:
    """Find text/attribute at xpath, return None if not found."""
    found = elem.find(xpath, _NS)
    return found if found is not None else None


# ══════════════════════════════════════════════
# Color extraction
# ══════════════════════════════════════════════

def _extract_clr_scheme(theme_root) -> dict[str, str]:
    """Extract the 12-color clrScheme from the OOXML theme element.

    Returns dict like {'dk1': '000000', 'lt1': 'FFFFFF', 'accent1': '4F81BD', ...}
    """
    scheme = {}
    clr_scheme = theme_root.find(".//a:clrScheme", _NS)
    if clr_scheme is None:
        return scheme

    for child in clr_scheme:
        tag = child.tag.split("}")[-1]  # e.g. 'dk1', 'lt1', 'accent1'
        # Try srgbClr first, then sysClr lastClr
        srgb = child.find("a:srgbClr", _NS)
        if srgb is not None:
            scheme[tag] = srgb.get("val", "").upper()
        else:
            sys_clr = child.find("a:sysClr", _NS)
            if sys_clr is not None:
                scheme[tag] = sys_clr.get("lastClr", "000000").upper()
    return scheme


def _extract_font_scheme(theme_root) -> dict[str, str]:
    """Extract major/minor font typefaces.

    Returns dict like {'heading': 'Calibri', 'body': 'Calibri'}
    """
    fonts = {}
    major = theme_root.find(".//a:majorFont/a:latin", _NS)
    minor = theme_root.find(".//a:minorFont/a:latin", _NS)
    if major is not None:
        fonts["heading"] = major.get("typeface", "Calibri")
    if minor is not None:
        fonts["body"] = minor.get("typeface", "Calibri")
    return fonts


def _collect_layout_colors(pptx_path: str) -> Counter:
    """Scan all slide layouts for srgbClr values in solidFill contexts.

    Returns a Counter of hex color strings (uppercase, no #).
    """
    counter: Counter = Counter()
    with zipfile.ZipFile(pptx_path) as z:
        for name in z.namelist():
            if not name.startswith("ppt/slideLayouts/"):
                continue
            root = etree.fromstring(z.read(name))
            for clr in root.iter(f'{{{_NS["a"]}}}srgbClr'):
                val = clr.get("val", "").upper()
                if not val or len(val) != 6:
                    continue
                parent_tag = clr.getparent().tag.split("}")[-1]
                # Only count fills (solidFill) — skip outline/effect colors
                if parent_tag == "solidFill":
                    counter[val] += 1
    return counter


def _collect_font_names(pptx_path: str) -> Counter:
    """Scan layouts for latin typeface declarations to find actual fonts used."""
    counter: Counter = Counter()
    with zipfile.ZipFile(pptx_path) as z:
        for name in z.namelist():
            if not name.startswith("ppt/slideLayouts/"):
                continue
            root = etree.fromstring(z.read(name))
            for latin in root.iter(f'{{{_NS["a"]}}}latin'):
                tf = latin.get("typeface", "")
                if tf and not tf.startswith("+"):  # skip theme refs like "+mj-lt"
                    counter[tf] += 1
    return counter


# ══════════════════════════════════════════════
# Color classification heuristics
# ══════════════════════════════════════════════

def _luminance(hex_color: str) -> float:
    """Compute relative luminance (0=black, 1=white) from hex string."""
    r = int(hex_color[0:2], 16) / 255.0
    g = int(hex_color[2:4], 16) / 255.0
    b = int(hex_color[4:6], 16) / 255.0
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _classify_colors(colors: Counter, clr_scheme: dict) -> dict:
    """Classify extracted colors into palette roles using heuristics.

    Strategy:
    1. Layout fill colors are the PRIMARY source (actual template colors)
    2. clrScheme is used only as fallback for roles not found in layouts
    3. Luminance-based bucketing: dark < 0.25, mid 0.25-0.65, light >= 0.65
    """
    palette = {}

    # ── Step 1: Classify actual layout colors by luminance ──
    sorted_colors = colors.most_common()

    dark_colors = [(c, n) for c, n in sorted_colors if _luminance(c) < 0.25]
    mid_colors = [(c, n) for c, n in sorted_colors if 0.25 <= _luminance(c) < 0.65]
    light_colors = [(c, n) for c, n in sorted_colors if _luminance(c) >= 0.65]

    # ── Dark bucket: navy, dark_navy, dark_text ──
    if dark_colors:
        # Most frequent dark = dark_text (used in body text fill)
        # Second most frequent dark = navy (header bars, backgrounds)
        # Third = dark_navy
        if len(dark_colors) >= 3:
            palette["dark_text"] = dark_colors[0][0]
            palette["navy"] = dark_colors[1][0]
            palette["dark_navy"] = dark_colors[2][0]
        elif len(dark_colors) == 2:
            # Darker one = dark_navy, lighter one = navy
            c1, c2 = dark_colors[0][0], dark_colors[1][0]
            if _luminance(c1) < _luminance(c2):
                palette["dark_text"] = c1
                palette["navy"] = c2
            else:
                palette["dark_text"] = c1
                palette["navy"] = c2
            palette["dark_navy"] = min([c1, c2], key=_luminance)
        elif len(dark_colors) == 1:
            palette["navy"] = dark_colors[0][0]
            palette["dark_text"] = dark_colors[0][0]

    # ── Mid bucket: accent, mid_gray, teal ──
    if mid_colors:
        # Most frequent mid = mid_gray (connector/subtle elements)
        # Second = accent (prominent brand color, usually more saturated)
        # Third = teal or other accent
        if len(mid_colors) >= 3:
            palette["mid_gray"] = mid_colors[0][0]
            palette["accent"] = mid_colors[1][0]
            palette["teal"] = mid_colors[2][0]
        elif len(mid_colors) == 2:
            palette["mid_gray"] = mid_colors[0][0]
            palette["accent"] = mid_colors[1][0]
        elif len(mid_colors) == 1:
            palette["accent"] = mid_colors[0][0]

    # ── Light bucket: white, ice_blue, light_gray, panel_gray, card_bg ──
    if light_colors:
        for c, _ in light_colors:
            lum = _luminance(c)
            if lum >= 0.99 and "white" not in palette:
                palette["white"] = c
            elif 0.80 <= lum < 0.92 and "ice_blue" not in palette:
                palette["ice_blue"] = c
            elif 0.92 <= lum < 0.96 and "panel_gray" not in palette:
                palette["panel_gray"] = c
            elif 0.96 <= lum < 0.99 and "card_bg" not in palette:
                palette["card_bg"] = c

        # light_gray = best candidate for slide background
        for c, _ in light_colors:
            lum = _luminance(c)
            if 0.90 <= lum < 0.98 and c != palette.get("ice_blue"):
                palette["light_gray"] = c
                break

    # ── Step 2: Fill in missing roles with defaults ──
    defaults = {
        "navy": "1E2761",
        "dark_navy": "141B41",
        "ice_blue": "CADCFC",
        "white": "FFFFFF",
        "light_gray": "F5F7FA",
        "panel_gray": "EDF0F7",
        "mid_gray": "94A3B8",
        "dark_text": "1E293B",
        "accent": "3B82F6",
        "accent_dark": "2563EB",
        "teal": "06B6D4",
        "amber": "F59E0B",
        "soft_navy": "2D3A6E",
        "card_bg": "F0F4FF",
    }

    for name, default_val in defaults.items():
        if name not in palette:
            palette[name] = default_val

    # Derive accent_dark from accent (slightly darker) if not set
    if "accent_dark" not in palette:
        palette["accent_dark"] = palette.get("accent", defaults["accent_dark"])

    return palette


# ══════════════════════════════════════════════
# Main extraction pipeline
# ══════════════════════════════════════════════

def extract_theme(pptx_path: str) -> dict:
    """Extract a ThemeConfig-compatible dict from a PPTX file.

    Returns a dict ready for yaml.dump() or ThemeConfig.from_yaml().
    """
    pptx_path = str(pptx_path)

    # ── Read OOXML theme ──
    with zipfile.ZipFile(pptx_path) as z:
        # Find theme file (usually ppt/theme/theme1.xml)
        theme_files = [n for n in z.namelist() if n.startswith("ppt/theme/")]
        if not theme_files:
            print("Warning: No theme file found in PPTX. Using defaults.", file=sys.stderr)
            theme_root = None
        else:
            theme_root = etree.fromstring(z.read(theme_files[0]))

    # ── Extract from OOXML theme ──
    clr_scheme = _extract_clr_scheme(theme_root) if theme_root is not None else {}
    font_scheme = _extract_font_scheme(theme_root) if theme_root is not None else {}

    # ── Scan layouts for actual colors and fonts ──
    layout_colors = _collect_layout_colors(pptx_path)
    layout_fonts = _collect_font_names(pptx_path)

    # ── Classify colors into palette roles ──
    palette = _classify_colors(layout_colors, clr_scheme)

    # ── Determine fonts ──
    fonts = {"heading": "Georgia", "body": "Calibri", "mono": "Consolas"}

    # Prefer layout-observed fonts over theme fonts
    if layout_fonts:
        top_fonts = layout_fonts.most_common(3)
        # Heuristic: heading font is often the less-frequent one (used only in titles)
        # body font is the most frequent
        if len(top_fonts) >= 2:
            fonts["body"] = top_fonts[0][0]
            fonts["heading"] = top_fonts[1][0]
        elif len(top_fonts) == 1:
            fonts["body"] = top_fonts[0][0]
            fonts["heading"] = top_fonts[0][0]
    elif font_scheme:
        fonts.update(font_scheme)

    # ── Build diagram_style from dominant colors ──
    diagram_style = {}

    # slide_bg: lightest frequent color
    if palette.get("light_gray"):
        diagram_style["slide_bg"] = f"#{palette['light_gray']}"

    # header bar color: darkest frequent color
    if palette.get("navy"):
        diagram_style["header_bar_color"] = f"#{palette['navy']}"
        diagram_style["title_font_color"] = f"#{palette['navy']}"

    diagram_style["header_font_color"] = f"#{palette.get('white', 'FFFFFF')}"
    diagram_style["header_subtitle_color"] = f"#{palette.get('ice_blue', 'CADCFC')}"
    diagram_style["edge_color"] = f"#{palette.get('mid_gray', '94A3B8')}"

    # ── Compose final theme dict ──
    theme_name = Path(pptx_path).stem.replace("_", " ")

    result = {
        "name": theme_name,
        "palette": palette,
        "fonts": fonts,
        "diagram_style": diagram_style,
        # node_defaults are not extractable from PPTX — use Midnight Executive defaults
        # Users should customize these manually based on their design preferences
    }

    return result


def theme_to_yaml(theme_dict: dict) -> str:
    """Convert theme dict to a formatted YAML string with comments."""
    lines = []
    lines.append("# ThemeConfig YAML — extracted from PPTX file")
    lines.append("# ")
    lines.append("# Palette and fonts were auto-extracted from the OOXML theme and slide layouts.")
    lines.append("# node_defaults are NOT extractable from PPTX. Customize manually if needed.")
    lines.append("# See DETAILED_DESIGN.md §7 for full ThemeConfig specification.")
    lines.append("#")
    lines.append(f"# Source: {theme_dict.get('name', 'unknown')}")
    lines.append("")

    # Use yaml.dump but with custom formatting
    yaml_str = yaml.dump(
        theme_dict,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        width=120,
    )
    lines.append(yaml_str)
    return "\n".join(lines)


# ══════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pptx_to_theme",
        description="Extract a ThemeConfig YAML from an existing PPTX file.",
        epilog="""\
Examples:
  python pptx_to_theme.py template.pptx -o themes/my_theme.yaml
  python pptx_to_theme.py template.pptx          # print to stdout
  python pptx_to_theme.py template.pptx --stats   # show extraction stats
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("input", help="Input PPTX file path")
    parser.add_argument("-o", "--output", default=None, help="Output YAML file path (default: stdout)")
    parser.add_argument("--stats", action="store_true", help="Show extraction statistics")
    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    if not input_path.suffix.lower() in (".pptx", ".pptm"):
        print(f"Warning: Expected .pptx file, got {input_path.suffix}", file=sys.stderr)

    # ── Extract ──
    theme_dict = extract_theme(str(input_path))

    # ── Stats ──
    if args.stats:
        layout_colors = _collect_layout_colors(str(input_path))
        layout_fonts = _collect_font_names(str(input_path))
        print("=== Extraction Statistics ===", file=sys.stderr)
        print(f"  Layout colors found: {len(layout_colors)} unique", file=sys.stderr)
        print(f"  Top 10 colors:", file=sys.stderr)
        for color, count in layout_colors.most_common(10):
            lum = _luminance(color)
            cat = "dark" if lum < 0.25 else ("mid" if lum < 0.65 else "light")
            print(f"    #{color}  (×{count:3d}, lum={lum:.2f}, {cat})", file=sys.stderr)
        print(f"  Fonts found: {len(layout_fonts)} unique", file=sys.stderr)
        for font, count in layout_fonts.most_common(5):
            print(f"    {font}  (×{count})", file=sys.stderr)
        print("", file=sys.stderr)

    # ── Output ──
    yaml_text = theme_to_yaml(theme_dict)

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(yaml_text, encoding="utf-8")
        print(f"✓ Theme extracted: {out_path}", file=sys.stderr)
        print(f"  Name: {theme_dict['name']}", file=sys.stderr)
        print(f"  Fonts: heading={theme_dict['fonts']['heading']}, body={theme_dict['fonts']['body']}", file=sys.stderr)
        print(f"  Palette: {len(theme_dict['palette'])} colors", file=sys.stderr)
    else:
        print(yaml_text)


if __name__ == "__main__":
    main()
